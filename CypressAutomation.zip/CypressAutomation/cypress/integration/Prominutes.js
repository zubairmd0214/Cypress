describe('My First Test suite',function()
 {

  //onbeforeunload = function (e) {
    //console.log('app window.onbeforeunload')
    //cy.wait(10000);
  //}
it('Verify title of the page', function ()
     {
      //expect(true).to.equal(true)
//cy.visit('https://devprominutes.quantana.com.au/')

cy.visit('https://devprominutes.quantana.com.au/', { onBeforeLoad: (abc) => { abc.sessionStorage.clear()}})
//cy.visit('/', { onBeforeLoad: (win) => { win.sessionStorage.clear() } });
//cy.wait(10000);
cy.title().should('eq','Login | ProMinutes')
//cy.wait(10000);
//cy.get('input[name=username]').type("v@quantana.in")
//cy.get(':nth-child(1) > .form-control')//cy.get(.form-control)
cy.get(':nth-child(1) > .form-control').type("v@quantana.in")

    // {enter} causes the form to submit  form-control
   //cy.get('input[name=password]').type(`${pro123}{enter}`)

cy.get('.input-group > .form-control').type("pro123{enter}")

cy.title().should('eq','WorkBench | Prominutes')
   //cy.get('.row.mt-3 > :nth-child(1)')

//Click on meet now
cy.get("#main_body_div > div.row.body_height.bg-white.no-gutters > div > div.row.mt-3 > div.col-6.text-center > button").click()


cy.get('#h_i0').type('Cypress Agenda Creation')
//cy.get('.bg_light_blue > tr > .align-middle > .row').type("Cypress Agenda Testing")
//cy.get('#h_i0').type("Cypress Agenda Testing")

cy.get('#\30 ').type("Cypress Minute Testing")
cy.wait(10000);
//cy.get(':nth-child(1) > .multiselect > .multiselect__tags').type("Action")

    })
  })
