/// <reference types="cypress" />

// const { delay } = require("cypress/types/bluebird")

describe('My First Test suite', function () {
    //onbeforeunload = function (e) {
    //console.log('app window.onbeforeunload')
    //cy.wait(1000);
    //}
   /* it('Verify title of the page', function () {
        //expect(true).to.equal(true)
        //cy.visit('https://devprominutes.quantana.com.au/')
        cy.visit('https://devprominutes.quantana.com.au', {
            onBeforeLoad: (abc) => {
                abc.sessionStorage.clear()
            }
        })
        /////////////////////////////////////////////////////////////////////////////////////

        describe('Testing API Endpoints Using Cypress', () => {

           it('Test GET Request', () => {
                  cy.request('http://localhost:3000/api/posts/1')
                       .then((response) => {
                              expect(response.body).to.have.property('code', 200);
                  })
            }) */
      
           it('Test POST Request', () => {
                  cy.request({ method: 'GET',url: 'https://k4-dev-api.herokuapp.com/getUserTPP/',
                       body: {
                           "userId": '61317d7b703d44bc7619203c'
                           //"password":'>3B2eQm3'
                       }
                  }).then((response) => { 
                         expect(response.body).has.property('title','loginSuccess')
                  })
            })
      
           /* it(“Test PUT Request”, () => {
                  cy.request({
                          method: ‘PUT’,
                          url: ‘http://localhost:3000/api/posts/2’,
                          body: { 
                             “id”: 2,
                             “title” : “Test Automation”
                          }
                  }).then((response) => { 
                          expect(response.body).has.property(“title”,“ Test Automation”); 
                  })          
            })        
      
            it(“Test DELETE Request”, () => {
                  cy.request({
                            method : ‘DELETE’,
                            url: ‘http://localhost:3000/api/post/2’
                            }).then((response) => {
                              expect(response.body).to.be.empty;
                  })	
            })
         
       })

        //////////////////////////////////////////////////////////////////////////////////
        //cy.wait(1000);
        cy.title().should('eq', 'Login | ProMinutes') //This is to verify the title of the app
        //cy.wait(1000);
        cy.get(':nth-child(1) > .form-control').type("ramesh@quantana.in") //Enter User Email
        cy.get('.input-group > .form-control').type("pro123{enter}") //Enter password and then press the enter key
        cy.title().should('eq', 'WorkBench | Prominutes') // Verify the title after login in Workbench
        //Click on meet now button
        cy.contains('Meet Now').click({
            force: true
        })
        cy.get('[data-text="Add Agenda here"]').click().type('Test the Agenda Input field') // Enter agenda description
        cy.get('[data-text="Enter Instant Meeting Description here"]').click({ force: true }).type('Test Minute Input field') //Enter Minute description
        cy.get('.multiselect__single').type('{enter}') // select type action
        cy.get('.mt-4 > .multiselect > .multiselect__tags').click().type('{downarrow}{enter}', { delay: 1000 });//Select group from dropdown
        cy.wait(1000);
        cy.get('.col-4 > .btn').click({ force: true }, { delay: 100 }) //click on close meeting button
        cy.get('.row > :nth-child(1) > .btn').click(); //close and publish meeting
        cy.wait(1000);
        cy.get('#menu_header > div > .w-40').click({ force: true }) //click on Hamburger menu button
        cy.get('[href="/meetings"] > .list-group-item > :nth-child(1) > .w-30').click({ force: true })// Click on "Meetings" button

    })*/

    Cypress.on('uncaught:exception', (err, runnable) => {
        // returning false here prevents Cypress from
        // failing the test
        return false
    })

})
    