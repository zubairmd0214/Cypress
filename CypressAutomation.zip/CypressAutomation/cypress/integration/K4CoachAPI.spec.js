/// <reference types="cypress" />

describe('K4Coach API Automation Testing', ()=>{

  /* it('POST Login API', () => {

     

     cy.request('GET', 'https://k4-dev-api.herokuapp.com/login').then((response) => {
       expect(response.status).equal(200)
       expect(response.body.data[0].firstName).equal('Michel')
     }) // This is for GET method


     })*/

  var Auth = {

    "username": "K4-api-dev",
    "password": "DataTeam@2021"

  }


  it("Login API test case", () => {
    /* var user = {

       "username": "K4-api-dev",
       "password": "DataTeam@2021"

     }*/
    var user1 = {

      "username": "kumar.parakala@ghd.com",
      "password": ">3B2eQm3"

    }

    cy.request({
      url: "https://k4-dev-api.herokuapp.com/login",
      method: "POST",
      auth: Auth,
      body: user1,
      failOnStatusCode: false
    }).then((response) => {
      expect(response.status).equal(200)
      expect(response.body.loginSuccess).equal(true)
      retryOnStatusCodeFailure: true // this is not required now



    })
    cy.log('Login API successfully tested')

  })

  it('Get User TPP API test case', () => {
    var userID = {
      userId: "61317d7b703d44bc7619203c"
    }

    cy.request({
      url: "https://k4-dev-api.herokuapp.com/getUserTPP/",
      method: "POST",
      auth: Auth,
      body: userID,
      failOnStatusCode: false
    }).then((response) => {

      expect(response.status).equal(200)
      //expect(response.body).equal('{ Object (teamProfileReport) }')
    })

    cy.log('Get User TPP API successfully tested')


  })

  it('4FSummary API Test case', () => {

    var TPPId = {
      "TPPId": 1
    }


    cy.request({
      url: "https://k4-dev-api.herokuapp.com/4FSummary",
      method: "POST",
      auth: Auth,
      body: TPPId,
      failOnStatusCode: false
    }).then((response) => {
      expect(response.status).equal(200)
      //expect(response.body)
      cy.log('4FSummary API successfully tested')

    })


  })

  it('Insights API test case', () => {

    var body = {

      TPPId: 1,
      userId: "61317d7b703d44bc7619203c"
    }

    cy.request({
      url: "https://k4-dev-api.herokuapp.com/insights/",
      method: "POST",
      auth: Auth,
      body: body,
      failOnStatusCode: false
    }).then((response) => {

      expect(response.status).equal(200)
      cy.log('Insights API tested successfully')

    })

  })


})