/// <reference types="cypress" />
describe('My First Test suite', function () {
  //onbeforeunload = function (e) {
  //console.log('app window.onbeforeunload')
  //cy.wait(10000);
  //}
  it('Verify title of the page', function () {
      //expect(true).to.equal(true)
      //cy.visit('https://devprominutes.quantana.com.au/')
      cy.visit('https://devprominutes.quantana.com.au', {
          onBeforeLoad: (abc) => {
              abc.sessionStorage.clear()
          }
      })
      //cy.wait(10000);
      cy.title().should('eq', 'Login | ProMinutes') //This is to verify the title of the app
      //cy.wait(10000);
      cy.get(':nth-child(1) > .form-control').type("ramesh@quantana.in") //Enter User Email
      cy.get('.input-group > .form-control').type("pro123{enter}") //Enter password and then press the enter key
      cy.title().should('eq', 'WorkBench | Prominutes') // Verify the title after login in Workbench
      //Click on meet now button
      cy.contains('Meet Now').click({
          force: true
      })
      cy.get('[data-text="Add Agenda here"]').click().type('Test the Agenda Input field') // Enter agenda description
      cy.get('[data-text="Enter Instant Meeting Description here"]').click({ force: true }).type('Test Minute Input field') //Enter Minute description
      cy.get('.multiselect__single').type('{enter}') // select type action
      //Select group from dropdown
      //cy.get('.mt-4 > .multiselect > .multiselect__content-wrapper > .multiselect__content > :nth-child(2) > .multiselect__option').type('{enter}')
      // cy.get('.mt-4 > .multiselect > .multiselect__tags').select('DEV GROUP').click()
      // cy.get('.multiselect').find('div span').contains('ASSET MANAGEMENT').click({ force: true })
      cy.get('.mt-4 > .multiselect > .multiselect__content-wrapper > .multiselect__content > :nth-child(3) > .multiselect__option').contains('ASSET MANAGEMENT').click({ force: true })
      // cy.get('.mt-4 > .multiselect > .multiselect__content-wrapper > .multiselect__content > :nth-child(3) >.multiselect__option').type('{enter}')
     // cy.get('#main_body_div > div.row.body_height.no-gutters > div > div > div.bg-white.instant_row_col.instant_row_col_members.border-right.border-left.col > div:nth-child(1) > div.col-4.text-right > button').contains('Close Meeting').click({ force: true })
      cy.get('.col-4 > .btn').click({ force: true }) //click on close meeting button
      cy.wait(3000)
      cy.contains('Close and Publish Now').click({ force: true })// click on publish meeting button
      //cy.get('.row > :nth-child(1) > .btn').contains('Close and Publish Now').click({ force: true })
     // cy.get('.row > :nth-child(1) > .btn').click({ force: true })
      cy.get('#menu_header > div > .w-40').click({ force: true }) //click on Hamburger menu button
                ///cy.get('[id="sidebar"]').click({ force: true }) //click on Hamburger menu button
               // cy.get('#menu_header').click({ force: true }) //click on Hamburger menu button
      cy.get('#sidebar > ul > a:nth-child(2) > li > span.align-middle').contains('Meetings').click({ force: true })
     
      //---------------------------
      //cy.get('#main_body_div > div.row.body_height.bg-white.no-gutters > div > div.row.mt-2 > div > table > tbody:nth-child(2) > tr:nth-child(1) > td.bg_light_blue.text-center.align-middle.position-sticky.head_col > u').find('td u').contains('M-').click({force: true})
      cy.get('#main_body_div > div.row.body_height.bg-white.no-gutters > div > div.row.mt-2 > div > table > tbody:nth-child(2) > tr:nth-child(1)').click()
      
      
      Cypress.on('uncaught:exception', (err, runnable) => {
          // returning false here prevents Cypress from failing the test
          return false
      })
  })
})